#!/bin/bash

# Absolute path to store monitor logs
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$SCRIPT_DIR/monitor.log"
SYS_LOG="/var/log/syslog"

# List of words to monitor in logs
KEYWORDS=("error" "critical" "fail")

echo "==== LOG MONITOR STARTED at $(date) ====" | tee -a "$LOG_FILE"

while true
do
    for word in "${KEYWORDS[@]}"
    do
        MATCHES=$(sudo grep -i "$word" "$SYS_LOG")

        if [[ ! -z "$MATCHES" ]]; then
            echo -e "\n MATCH FOUND: '$word' at $(date)" | tee -a "$LOG_FILE"
            echo "$MATCHES" | tee -a "$LOG_FILE"

            # Optional Desktop Notification (only if available)
            if command -v notify-send &>/dev/null; then
                notify-send "⚠ ALERT" "Found: $word in logs"
            fi
        fi
    done
    
    sleep 5
done


