#!/bin/bash

# Universal error handler for scripts

ERROR_LOG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../logs/error.log"

handle_error() {
    echo "❌ ERROR: $1 at $(date)" | tee -a "$ERROR_LOG"
}

# Use in other scripts like this:
# handle_error "Backup failed due to wrong path"
