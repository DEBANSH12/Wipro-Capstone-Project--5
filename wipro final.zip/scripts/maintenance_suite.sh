#!/bin/bash

while true; do
echo "
========================================
     SYSTEM MAINTENANCE SUITE (BASH)
========================================
1. Run Backup Script
2. Run System Update + Cleanup
3. Start Log Monitoring
4. Exit
========================================
"
read -p "Enter your choice: " choice

case $choice in
    1) ./backup.sh ;;
    2) ./update_cleanup.sh ;;
    3) ./log_monitor.sh ;;
    4) echo "Exiting..."; exit 0 ;;
    *) echo "Invalid option!" ;;
esac
done
