O#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$SCRIPT_DIR/../logs/test_results.log"

SCRIPTS=("backup.sh" "update_cleanup.sh" "log_monitor.sh" "maintenance_suite.sh")

echo "==== TEST RUN STARTED: $(date) ====" | tee "$LOG_FILE"

# Check if required scripts exist
for script in "${SCRIPTS[@]}"; do
    if [[ -f "$SCRIPT_DIR/$script" ]]; then
        echo "✔ Found: $script" | tee -a "$LOG_FILE"
    else
        echo "❌ MISSING: $script" | tee -a "$LOG_FILE"
        exit 1
    fi
done

# Check if scripts are executable
for script in "${SCRIPTS[@]}"; do
    if [[ -x "$SCRIPT_DIR/$script" ]]; then
        echo "✔ Executable: $script" | tee -a "$LOG_FILE"
    else
        echo "❌ Not executable: $script — fixing..." | tee -a "$LOG_FILE"
        chmod +x "$SCRIPT_DIR/$script"
    fi
done

# Test backup script
echo "🚀 Running backup test..." | tee -a "$LOG_FILE"
bash "$SCRIPT_DIR/backup.sh"
[[ $? -eq 0 ]] && echo "✅ Backup test passed" | tee -a "$LOG_FILE" || echo "❌ Backup test failed" | tee -a "$LOG_FILE"

# Test update cleanup script
echo "🚀 Running update test..." | tee -a "$LOG_FILE"
bash "$SCRIPT_DIR/update_cleanup.sh"
[[ $? -eq 0 ]] && echo "✅ Update test passed" | tee -a "$LOG_FILE" || echo "❌ Update test failed" | tee -a "$LOG_FILE"

# Test log monitor script
echo "🚀 Simulating log event for monitoring test..." | tee -a "$LOG_FILE"
echo "fake critical system failure" | sudo tee -a /var/log/syslog >/dev/null
bash "$SCRIPT_DIR/log_monitor.sh" & sleep 3 && kill $!
[[ $? -eq 0 ]] && echo "✅ Log monitoring test passed" | tee -a "$LOG_FILE" || echo "❌ Log monitoring failed" | tee -a "$LOG_FILE"

echo "==== TEST RUN FINISHED: $(date) ====" | tee -a "$LOG_FILE"
