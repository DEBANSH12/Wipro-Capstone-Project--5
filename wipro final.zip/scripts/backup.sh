#!/bin/bash

# ===== CONFIG =====
SOURCE="/home/pixel/Desktop/assignment5/scripts/backups"    
DEST="../backups"
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
LOG_FILE="../logs/backup.log"

# ===== EXECUTION =====
echo "==== BACKUP STARTED: $TIMESTAMP ====" | tee -a $LOG_FILE

if [ ! -d "$SOURCE" ]; then
    echo "Source folder not found!" | tee -a $LOG_FILE
    exit 1
fi

mkdir -p "$DEST"
TARGET="$DEST/backup_$TIMESTAMP.tar.gz"

tar -czf "$TARGET" "$SOURCE" 2>>$LOG_FILE

if [ $? -eq 0 ]; then
    echo "Backup successful: $TARGET" | tee -a $LOG_FILE
else
    echo "Backup FAILED!" | tee -a $LOG_FILE
fi

echo "==== BACKUP COMPLETED ====" | tee -a $LOG_FILE
