#!/bin/bash

LOG_FILE="/home/pixel/Desktop/assignment5/scripts/logs"

echo "===== SYSTEM UPDATE STARTED =====" | tee -a $LOG_FILE
sudo apt update && sudo apt upgrade -y | tee -a $LOG_FILE
sudo apt autoremove -y | tee -a $LOG_FILE
sudo apt clean -y | tee -a $LOG_FILE
echo "===== SYSTEM UPDATE COMPLETED =====" | tee -a $LOG_FILE
